#ifndef COMMON_H
#define COMMON_H
#include <stdint.h>
struct Message {
    int compteur;
};
#endif
